# Snake Boss v5
This is the latest version of the game with updated UI and logo.